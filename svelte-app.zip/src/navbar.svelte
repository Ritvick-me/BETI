<style>

	.rvp-hello{
		height: 700px;
		width: 100%;
		background-color: black;
	}

</style>

<div class="rvp-hello">
	hello
</div>