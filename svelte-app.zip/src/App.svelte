<script>
	import navbar from './navbar.svelte'
	let name = 'world';
</script>

<navbar/>